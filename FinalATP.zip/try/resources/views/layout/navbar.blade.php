@extends('layout.main')

@section('navbar')
<a href="/app/create">Create New Employee</a> |
<a href="/app/userlist">View User List</a> |
<a href="/app/users">Search User</a> |
<a href="/app/logout">logout</a>
@endsection