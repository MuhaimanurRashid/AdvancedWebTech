const express 	= require('express');
const userModel		= require.main.require('./models/userModel');
const router 	= express.Router();

router.get('*',  (req, res, next)=>{
	if(req.cookies['username'] == null){
		res.redirect('/login');
	}else{
		next();
	}
});

router.get('/create', (req, res)=>{
	res.render('user/create');
});
router.post('/create', (req, res)=>{

    var user=
    {
        ename: req.body.ename,
        cname: req.body.cname,
        contactno: req.body.contactno,
        username: req.body.username,
        password: req.body.password,
      

    };
    userModel.insert(user, function(status){

        if(status){
    
            console.log("Created");
            res.render('/create'); 
        }
        else{
              console.log("Error");  
        }
    });
});

module.exports = router;